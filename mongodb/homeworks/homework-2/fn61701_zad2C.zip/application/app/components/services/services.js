'use strict';

angular.module('myApp.services', [
  'restangular',
  'myApp.services.albums-service',
  'myApp.services.artists-service',
  'myApp.services.strings-generator-service',
  'myApp.services.utils-service'
]);
