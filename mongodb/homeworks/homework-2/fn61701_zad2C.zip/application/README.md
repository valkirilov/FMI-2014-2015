angular-bootstrap-seed
======================

Seed for my Angular projects. Bootstrap and Grunt configuration included.

# Setup

    npm install
    bower install

# Run

    // Run mongo db.
    // Example
    export PATH=/home/valentin/mongo/bin:$PATH
    mongod --dbpath=/home/valentin/Documents/FMI-2014-2015/mongodb/homeworks/homework-2/

    node bin/www

    > Express server listening on port 12345
    > Public folder for the client set to be app/
    > /api/albums
    > /api/artists


