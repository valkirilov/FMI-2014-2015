//--------------------------------------------
// NAME: Valentin Kirilov
// CLASS: XIa
// NUMBER: 6
// PROBLEM: #5
// FILE NAME: advanced-shell.c (unix file name)
// FILE PURPOSE:
// Програмата реализира advanced shell
//---------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

char* parsed_results[32];
char* parsed_results_pipe[32];
char standard_input_changed[32];
char standard_output_changed[32];
int pipe_exist = 0;

struct Job {
	char* command_;
	char** argv_;
	int stdin_;
	int stdout_;

} typedef Job;

//--------------------------------------------
// FUNCTION: clear_parsed_results()
// The function clear and free memory from parsed results
// PARAMETERS:
// -none-
//----------------------------------------------
void clear_parsed_results()
{
	pipe_exist = 0;

	int index;
	for(index=0; index<32; index++)
	{
		parsed_results[index] = NULL;
		parsed_results_pipe[index] = NULL;
		//free(parsed_results[index]);
	}

	strcpy(standard_input_changed, "");
	strcpy(standard_output_changed, "");
}

//--------------------------------------------
// FUNCTION: char** parse_cmdline(const char* cmdline)
// The function parsing given stringline to array with strings
// PARAMETERS:
// Given line for parsing
//----------------------------------------------
char** parse_cmdline(const char* cmdline) 
{
	clear_parsed_results();

	char* current_string;				// Current string
	int current_string_index = 0;		// Index of the current separting string in the array
	int current_string_char_index = 0;	// Index of the char in the current separating string
	int current_char_index = 0;			// Current char index in the cmdline

	int current_string_pipe_index = 0;			// Index of the current separting string in the pipe array
	int current_string_pipe_char_index = 0;		// Index of the char in the current separating string in pipe

	int change_std = 0;
	int set_pipe = 0;

	// Go in the cmdline and check each symbol
	for(current_char_index = 0; current_char_index < strlen(cmdline); current_char_index++)
	{
		// If current sybmol is separator
		if((cmdline[current_char_index] == ' ') || (current_char_index == strlen(cmdline)-1))
		{
			// Add termination \0
			if(current_string != NULL) {
				if(pipe_exist == 1) {
					current_string[current_string_pipe_char_index] = '\0';
				}
				else {
					current_string[current_string_char_index] = '\0';
				}
			}

			// If we are changing the stdin or stdout
			if(change_std > 0) {
				// Skip first space after > or <
				if(current_string == NULL) {
					current_string = "";
					current_string_char_index = 0;
					continue;
				}

				// Save new stdin or stdout
				if(change_std == 1) {
					strcpy(standard_input_changed, current_string);
				}
				else {
					strcpy(standard_output_changed, current_string);
				}				

				// Clear variables and continue
				current_string = "";
				current_string_char_index = 0;
				change_std = 0;
			}
			// If we are setting a pipe
			else if(set_pipe > 0) {
				// Skip first spcae after |
				if(current_string == NULL) {
					set_pipe = 0;
					current_string = "";
					current_string_pipe_char_index = 0;
					continue;
				}
				pipe_exist = 1;

			}
			// If it is normal argument
			else {
				// Ip pipe exist add this argument to pipe array
				if(pipe_exist == 1) {
					parsed_results_pipe[current_string_pipe_index] = (char*)malloc(128 * sizeof(char));
					strcat(parsed_results_pipe[current_string_pipe_index], current_string);

					current_string_pipe_index++;
					current_string_pipe_char_index = 0;
				}
				// If the pipe is still don't exist add that argumetn to narmal array
				else {
					parsed_results[current_string_index] = (char*)malloc(128 * sizeof(char));
					strcat(parsed_results[current_string_index], current_string);
				}
			}

			// Continue to check
			current_string = "";
			current_string_char_index = 0;
			current_string_index++;
		}
		// If it is a symbol fro stdout or stdin change
		else if(cmdline[current_char_index] == '<' || cmdline[current_char_index] == '>') {
			if(cmdline[current_char_index] == '<') {
				change_std = 1;
			}
			else {
				change_std = 2;
			}
			current_string = NULL;
		}
		// If it is a pipe symbol
		else if(cmdline[current_char_index] == '|') {
			set_pipe = 1;
			pipe_exist = 1;

			current_string = NULL;
		}
		// If it is a argument normal letter
		else 
		{
			// If pipe exist add this letter to pipe arguments
			if(pipe_exist == 1) {
				if (current_string_pipe_char_index == 0)
					current_string = (char*)malloc(128 * sizeof(char));

				current_string[current_string_pipe_char_index] = cmdline[current_char_index];
				current_string_pipe_char_index++;
			}
			// If the pipe don't exist add tis letter to normal argumnets array
			else {
				if (current_string_char_index == 0)
					current_string = (char*)malloc(128 * sizeof(char));

				current_string[current_string_char_index] = cmdline[current_char_index];
				current_string_char_index++;
			}
		}
	}

	return parsed_results;
}

//--------------------------------------------
// FUNCTION: void run_command(Job job) 
// The function creating new proccess specifications and changes the stdin and stdout by given info
// PARAMETERS:
// Job job - structure with information for the new process
//----------------------------------------------
void run_command(Job job) {
	//printf("STDIN: %d\n", job.stdin_);
	//printf("STDOUT: %d\n", job.stdout_);

	//printf("command: %s\n", job.argv_[0]);
	//int i;
	//for(i=0; i < 10; i++) {
	//	printf("[%d] = %s\n", i, job.argv_[i]);
	//}

	dup2(job.stdin_, STDIN_FILENO);
	dup2(job.stdout_, STDOUT_FILENO);
	execv(job.argv_[0], job.argv_);
}

int main() {

	#define _STD_READ__ 0
	#define _STD_WRITE__ 1

	char read_line[512];
	int shell_pipe[2];

	while (fgets(read_line, 128, stdin) != NULL) 
	{
		if(strcmp(read_line, "\n") == 0) {
			continue;
		}

		char** parsed_line = parse_cmdline(read_line);
		int pid = fork();
		if (pid == 0) 
		{
			// Child process
			int curr_stdin = 0;
			int curr_stdout = 1;

			if(strcmp(standard_output_changed, "") != 0) {
				//printf("STDOUT: %s\n", standard_output_changed);
				int fd = open(standard_output_changed, O_WRONLY | O_CREAT, 0777);
				if (fd < 0)	{
					perror("open()");
				}
				else {
					curr_stdout = fd;
				}
			}

			if(strcmp(standard_input_changed, "") != 0) {
				//printf("STDIN: %s\n", standard_input_changed);

				FILE *fp;
	            char *line = NULL;
	            size_t size = 128;

	            fp = fopen(standard_input_changed, "r");
	            if (fp == NULL)
	                perror("fopen()");

	            curr_stdin = fp;
	            getline(&line, &size, fp);
	            char** parsed_line = parse_cmdline(line);

			}

			if(pipe_exist == 1) {
				printf("PIPE :(\n");
			}
			else {
				struct Job curr_job;
				curr_job.command_ = parsed_line[0];
				curr_job.argv_ = parsed_line;
				curr_job.stdin_ = curr_stdin;
				curr_job.stdout_ = curr_stdout;
				run_command(curr_job);
			}

			perror(parsed_line[0]);
		} 
		else if (pid > 0) 
		{
			// Parent process
			int status;
			waitpid(pid, &status, -1);
		} 
		else 
		{
			// Fork
			perror("fork()");
		}

	}
	return 0;
}